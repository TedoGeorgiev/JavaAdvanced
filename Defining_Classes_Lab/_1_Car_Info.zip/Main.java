package Defining_Classes_Lab;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int carNumber = Integer.parseInt(scanner.nextLine());

        List<Car> cars = new ArrayList<>();
        for (int i = 0; i < carNumber; i++) {
            String [] carDetails = scanner.nextLine().split("\\s+");
            Car car = new Car();
            car.setBrand(carDetails[0]);
            car.setModel(carDetails[1]);
            car.setHorsePower(Integer.parseInt(carDetails[2]));
            cars.add(car);
        }

        cars.forEach(System.out::println);

    }
}
