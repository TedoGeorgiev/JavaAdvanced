
import java.util.ArrayDeque;

public class Jar <T>{

    ArrayDeque<T> jarStack;

    public Jar () {
        this.jarStack = new ArrayDeque<>();
    }

    public void add (T element) {
        jarStack.push(element);
    }

    public T remove () {
        if (!jarStack.isEmpty()) {
            return jarStack.pop();
        }
        return null;
    }

    public ArrayDeque<T> getJarStack() {
        return jarStack;
    }

}
