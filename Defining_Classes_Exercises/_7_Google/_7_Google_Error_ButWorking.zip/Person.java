package Defining_Classes_Exercises._7_Google;


import java.util.ArrayList;
import java.util.List;

public class Person {
    private String personName;

    private Company company;
    private List<Pokemon> pokemonsList;
    private List<Parent> parentsList;
    private List<Children> childrenList;
    private Car car;

    public Person () {
        //company = null
        //car = null
        //parents = ������ ������
        this.parentsList = new ArrayList<>();
        //children = ������ ������
        this.childrenList = new ArrayList<>();
        //pokemons = ������ ������
        this.pokemonsList = new ArrayList<>();
    }

    public Person(Company company, List<Pokemon> pokemonsList, List<Parent> parentsList, List<Children> childrenList, Car car) {
        this.company = company;
        this.pokemonsList = pokemonsList;
        this.parentsList = parentsList;
        this.childrenList = childrenList;
        this.car = car;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public List<Pokemon> getPokemonsList() {
        return pokemonsList;
    }

    public void setPokemonsList(List<Pokemon> pokemonsList) {
        this.pokemonsList = pokemonsList;
    }

    public List<Parent> getParentsList() {
        return parentsList;
    }

    public void setParentsList(List<Parent> parentsList) {
        this.parentsList = parentsList;
    }

    public List<Children> getChildrenList() {
        return childrenList;
    }

    public void setChildrenList(List<Children> childrenList) {
        this.childrenList = childrenList;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("Company:").append("\n");
        if (company != null) {
            sb.append(company).append("\n");
        }
        sb.append("Car:").append("\n");
        if (car != null) {
            sb.append(car).append("\n");
        }

        sb.append("Pokemon:").append("\n");
        for (Pokemon pokemon : pokemonsList) {
            sb.append(pokemon).append("\n");
        }

        sb.append("Parents:").append("\n");
        for (Parent parent : parentsList) {
            sb.append(parent).append("\n");
        }

        sb.append("Children:").append("\n");
        for (Children child : childrenList) {
            sb.append(child).append("\n");
        }

        return sb.toString();
    }
}
